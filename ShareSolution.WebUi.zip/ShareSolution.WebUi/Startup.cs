﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ShareSolution.WebUi.Startup))]
namespace ShareSolution.WebUi
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
